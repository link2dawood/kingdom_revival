<?php
/**
 * DUMMY testimonials created by Setup (step "News stories and testimonials"), one per published ministry, so the
 * Testimonials page and each ministry's "Stories from the field" card have content. The names, places and words are
 * made up: replace or delete them (Testimonials) before launch. Each is marked with the post meta _krm_sample.
 *
 * Per testimonial: name (the title), role (role or place), ministry (slug from inc/data/ministries.php), text,
 * is_sample. Set is_sample to false before launch to hide that dummy from public visitors; administrators still see
 * it so it can be reviewed and replaced.
 *
 * @package Kingdom_Revival
 */

defined( 'ABSPATH' ) || exit;

return array(
	array( 'name' => 'Iqra Masih', 'role' => 'Freed family · Faisalabad district', 'ministry' => 'slavery-freedom', 'text' => 'For decades our whole family worked at the kiln to pay a debt that never got smaller. When the ministry cleared it, my children went to school for the first time. Now we work for ourselves.', 'is_sample' => true ),
	array( 'name' => 'Rehana Masih', 'role' => 'Widow and mother · Faisalabad district', 'ministry' => 'brick-kiln-family-care', 'text' => 'Rehana is a widow living in bonded labour at a brick kiln. After she gave birth she needed an operation she could not afford. The ministry paid for her surgery and cared for her and her baby through recovery.', 'is_sample' => true ),
	array( 'name' => 'Pastor Javed Masih', 'role' => 'House church · Faisalabad district', 'ministry' => 'church-planting', 'text' => 'We started with four families praying in my courtyard. Today more than forty people worship together every Sunday, and the village has its own church.', 'is_sample' => true ),
	array( 'name' => 'Rubina Pervaiz', 'role' => 'New believer · Faisalabad district', 'ministry' => 'bible-distribution', 'text' => 'I had never held a Bible in my own language. Now I read it to my children every evening, and my neighbours come to listen too.', 'is_sample' => true ),
	array( 'name' => 'Asif Gill', 'role' => 'Village outreach · Jhang district', 'ministry' => 'evangelism-outreach', 'text' => 'The team came to our village for an evening meeting. I heard the Gospel clearly for the first time that night, and my life has not been the same since.', 'is_sample' => true ),
	array( 'name' => 'Pastor Arshad Gill', 'role' => 'Village pastor · Jhang district', 'ministry' => 'leadership-training', 'text' => 'The training gave me tools to teach the Bible faithfully. I now train three younger leaders in my own church.', 'is_sample' => true ),
	array( 'name' => 'Naveed Sadiq', 'role' => 'Baptised 2025 · Faisalabad district', 'ministry' => 'baptisms-discipleship', 'text' => 'After months in a discipleship group I was baptised with my wife. We now lead a small group for new believers in our street.', 'is_sample' => true ),
	array( 'name' => 'Shamim Akhtar', 'role' => 'Prayer meeting · Faisalabad district', 'ministry' => 'prayer-deliverance', 'text' => 'Our family was carrying fear and sickness for years. The prayer team visited every week, and God brought peace into our home.', 'is_sample' => true ),
	array( 'name' => 'Rashid Masih', 'role' => 'Kiln worker · Faisalabad district', 'ministry' => 'brick-kiln-family-care', 'text' => 'When work stopped in the rains, the food parcels kept my family going. My two sons are now in school with books and uniforms.', 'is_sample' => true ),
	array( 'name' => 'Ayesha', 'role' => 'Children’s home · Faisalabad', 'ministry' => 'children-orphan-care', 'text' => 'After my parents died I had nowhere to go. Here I have food, school and people who pray for me. I want to become a teacher.', 'is_sample' => true ),
	array( 'name' => 'Iqbal Masih', 'role' => 'Village elder · Jhang district', 'ministry' => 'clean-water', 'text' => 'Our women used to walk an hour for water that made the children sick. The new hand pump is right in the village, and the water is clean.', 'is_sample' => true ),
	array( 'name' => 'Nasreen Bibi', 'role' => 'Widow · Faisalabad district', 'ministry' => 'widows-support', 'text' => 'After my husband died I could not feed my children. With the monthly groceries and the sewing class, I can now earn a living for my family.', 'is_sample' => true ),
);
