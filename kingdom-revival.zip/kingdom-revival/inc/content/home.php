<?php
/**
 * Home page content (front-page.php and template-parts/home/*). Defaults are the approved design's content.
 * The impact numbers come from Kingdom Revival → Settings; the ministry explorer lists the published ministries.
 *
 * @package Kingdom_Revival
 */

defined( 'ABSPATH' ) || exit;

$krm_up     = 'https://kingdomrevivalministries.com/wp-content/uploads/';
$krm_poster = $krm_up . 'elementor/thumbs/General-pictures-14-scaled-e1787296605557-rs80at0e3asoxo6sbplvoojsdrcp1u64t5zrilqm40.jpg';
$krm_video  = $krm_up . '2026/08/a.mp4';
$krm_hl     = __( 'Wrap highlighted words in <span style="color: #F5A04A">…</span>.', 'kingdom-revival' );

return array(
	'hero'     => array(
		'label'  => __( 'Hero and donation card', 'kingdom-revival' ),
		'fields' => array(
			'image'          => krm_f( 'image', __( 'Background image (also shown before the video plays)', 'kingdom-revival' ), $krm_poster ),
			'video'          => krm_f( 'url', __( 'Background video (MP4 link)', 'kingdom-revival' ), $krm_video, __( 'Upload the video in Media → Add New and paste its link here. Leave empty to show only the image.', 'kingdom-revival' ) ),
			'eyebrow'        => krm_f( 'text', __( 'Small heading', 'kingdom-revival' ), 'Bringing Hope to the Forgotten' ),
			'title'          => krm_f( 'html', __( 'Heading', 'kingdom-revival' ), 'Sharing the Hope of <span style="color: #F5A04A">Jesus Christ</span> with the Unreached & <span style="color: #F5A04A">Vulnerable</span>', $krm_hl ),
			'lead'           => krm_f( 'textarea', __( 'Introduction', 'kingdom-revival' ), 'We preach the Gospel, plant churches and care for brick kiln families, orphans and widows across Pakistan and beyond.' ),
			'button1_label'  => krm_f( 'text', __( 'Button text', 'kingdom-revival' ), 'Explore Ministries' ),
			'button1_url'    => krm_f( 'url', __( 'Button link', 'kingdom-revival' ), '#ministries' ),
			'button2_label'  => krm_f( 'text', __( 'Video link text', 'kingdom-revival' ), 'Watch Our Story' ),
			'button2_url'    => krm_f( 'url', __( 'Video link', 'kingdom-revival' ), '#field-stories' ),
			'card_badge'     => krm_f( 'text', __( 'Donation card: badge', 'kingdom-revival' ), 'MAKE AN IMPACT' ),
			'card_heading'   => krm_f( 'text', __( 'Donation card: heading', 'kingdom-revival' ), 'Help Brick Kiln Children Go to School & Know Christ' ),
			'card_text'      => krm_f( 'textarea', __( 'Donation card: text', 'kingdom-revival' ), 'Your gift provides Sunday school, education and care for children growing up beside the kilns.' ),
			'card_note'      => krm_f( 'textarea', __( 'Donation card: small print', 'kingdom-revival' ), 'Every gift helps children learn, grow in faith and build a brighter future.' ),
			'amounts'        => krm_f( 'text', __( 'Amounts (US dollars)', 'kingdom-revival' ), '25, 50, 100, 250', __( 'Used by the donation card and the floating “Donate” panel. Numbers separated by commas; “Other” is always added.', 'kingdom-revival' ) ),
			'default_amount' => krm_f( 'text', __( 'Amount selected at first', 'kingdom-revival' ), '50' ),
		),
	),
	'about'    => array(
		'label'  => __( 'About', 'kingdom-revival' ),
		'fields' => array(
			'image1'       => krm_f( 'image', __( 'Large photo', 'kingdom-revival' ), $krm_up . 'elementor/thumbs/Leadership-and-Discipleship-9-scaled-rsiplqicgeaowcet38ec7199etzmpejk72qt9zqxco.jpg' ),
			'image1_alt'   => krm_f( 'text', __( 'Large photo description (alt text)', 'kingdom-revival' ), 'Leadership and discipleship ministry' ),
			'image2'       => krm_f( 'image', __( 'Small photo', 'kingdom-revival' ), $krm_up . 'elementor/thumbs/Orphanages-care-16-scaled-e1787819076312-rsij8jj20ojpz9btf5v77vd2yjnnuanqoo6mn3kqjc.jpg' ),
			'image2_alt'   => krm_f( 'text', __( 'Small photo description (alt text)', 'kingdom-revival' ), 'Orphanage care ministry' ),
			'eyebrow'      => krm_f( 'text', __( 'Small heading', 'kingdom-revival' ), 'About Us' ),
			'heading'      => krm_f( 'html', __( 'Heading', 'kingdom-revival' ), 'A Gospel-Centred Ministry Serving Pakistan’s Forgotten' ),
			'checks'       => krm_f( 'textarea', __( 'Check list', 'kingdom-revival' ), "Proclaiming the Gospel to unreached communities\nPlanting churches and house churches\nCaring for orphans and brick kiln children\nDistributing Urdu Bibles to families", __( 'One point per line.', 'kingdom-revival' ) ),
			'text'         => krm_f( 'textarea', __( 'Text', 'kingdom-revival' ), 'Our mission is to glorify God by making disciples of Jesus Christ, proclaiming the Gospel among unreached communities, planting churches, equipping leaders, and serving vulnerable children and brick kiln families.' ),
			'button_label' => krm_f( 'text', __( 'Button text', 'kingdom-revival' ), 'About Us' ),
			'button_url'   => krm_f( 'url', __( 'Button link', 'kingdom-revival' ), '{about}' ),
		),
	),
	'explorer' => array(
		'label'  => __( 'Ministry explorer', 'kingdom-revival' ),
		'help'   => __( 'The list shows your published ministries. Each ministry’s explorer photo and position are set on the ministry (Ministries → edit).', 'kingdom-revival' ),
		'fields' => array(
			'eyebrow'       => krm_f( 'text', __( 'Small heading', 'kingdom-revival' ), 'Our Ministries' ),
			'heading'       => krm_f( 'html', __( 'Heading', 'kingdom-revival' ), 'Twelve ministries. One Gospel. Explore them.' ),
			'intro'         => krm_f( 'textarea', __( 'Introduction', 'kingdom-revival' ), 'Choose a ministry to see what it does and how your support reaches people.' ),
			'support_label' => krm_f( 'text', __( 'Support button text', 'kingdom-revival' ), 'Support this ministry' ),
			'support_url'   => krm_f( 'url', __( 'Support button link', 'kingdom-revival' ), '{donate}' ),
			'more_label'    => krm_f( 'text', __( 'Ministry page button text', 'kingdom-revival' ), 'See All' ),
		),
	),
	'causes'   => array(
		'label'  => __( 'Giving cards', 'kingdom-revival' ),
		'fields' => array(
			'eyebrow'      => krm_f( 'text', __( 'Small heading', 'kingdom-revival' ), 'Our Ministries' ),
			'heading'      => krm_f( 'html', __( 'Heading', 'kingdom-revival' ), 'You Can Bring Hope to Many by Giving a Little' ),
			'note'         => krm_f( 'textarea', __( 'Small print on every card', 'kingdom-revival' ), 'Your gift brings practical care and lasting hope through this ministry.' ),
			'button_label' => krm_f( 'text', __( 'Button text', 'kingdom-revival' ), 'Donate Now' ),
			'button_url'   => krm_f( 'url', __( 'Button link', 'kingdom-revival' ), '{donate}' ),
			'cards'        => krm_list_f(
				__( 'Cards', 'kingdom-revival' ),
				__( 'Card', 'kingdom-revival' ),
				array(
					'tag'   => krm_f( 'text', __( 'Label on the photo', 'kingdom-revival' ) ),
					'title' => krm_f( 'text', __( 'Title', 'kingdom-revival' ) ),
					'image' => krm_f( 'image', __( 'Photo', 'kingdom-revival' ) ),
					'text'  => krm_f( 'textarea', __( 'Text', 'kingdom-revival' ) ),
				),
				array_map(
					function ( $c ) {
						return array(
							'tag'   => $c[0],
							'title' => $c[1],
							'image' => $c[2],
							'text'  => $c[3],
						);
					},
					krm_home_causes()
				)
			),
		),
	),
	'field'    => array(
		'label'  => __( 'Ministry in action (video and photos)', 'kingdom-revival' ),
		'fields' => array(
			'eyebrow'         => krm_f( 'text', __( 'Small heading', 'kingdom-revival' ), 'Ministry programs' ),
			'heading'         => krm_f( 'text', __( 'Heading', 'kingdom-revival' ), 'See the ministry in action' ),
			'text'            => krm_f( 'textarea', __( 'Text', 'kingdom-revival' ), 'From evangelism and discipleship to children’s education, Bible distribution and practical care, Kingdom Revival Ministries serves families across Pakistan and beyond.' ),
			'video'           => krm_f( 'url', __( 'Video (MP4 link)', 'kingdom-revival' ), $krm_video ),
			'poster'          => krm_f( 'image', __( 'Image shown before the video plays', 'kingdom-revival' ), $krm_poster ),
			'video_title'     => krm_f( 'text', __( 'Video description (for screen readers)', 'kingdom-revival' ), 'Kingdom Revival Ministries featured video' ),
			'feature_eyebrow' => krm_f( 'text', __( 'Video: small heading', 'kingdom-revival' ), 'Featured video' ),
			'feature_heading' => krm_f( 'text', __( 'Video: heading', 'kingdom-revival' ), 'Faith, service and hope' ),
			'feature_text'    => krm_f( 'textarea', __( 'Video: text', 'kingdom-revival' ), 'Watch the ministry’s official video and explore real images from its work in Pakistan.' ),
			'feature_link'    => krm_f( 'text', __( 'Video: link text', 'kingdom-revival' ), 'Open video in a new tab' ),
			'photos'          => krm_list_f(
				__( 'Photos', 'kingdom-revival' ),
				__( 'Photo', 'kingdom-revival' ),
				array(
					'image'     => krm_f( 'image', __( 'Photo', 'kingdom-revival' ) ),
					'image_alt' => krm_f( 'text', __( 'Description (alt text)', 'kingdom-revival' ) ),
					'caption'   => krm_f( 'text', __( 'Caption', 'kingdom-revival' ) ),
				),
				array(
					array(
						'image'     => $krm_up . 'elementor/thumbs/Deliverance-and-Healing-ministry-5-scaled-e1787225773575-rs6kxdo5ygbat93txitcpifrbjmk10tf6j9kjqh6qg.jpg',
						'image_alt' => 'Deliverance and healing ministry',
						'caption'   => 'Prayer and healing ministry',
					),
					array(
						'image'     => $krm_up . 'elementor/thumbs/Bible-Distribution-rqhhvb1bt4op61pyxtdlg5smtcfpsj957ob37u8700.png',
						'image_alt' => 'Bible distribution',
						'caption'   => 'Sharing Scripture',
					),
					array(
						'image'     => $krm_up . 'elementor/thumbs/Urdu-Bible-Distribution-6-e1787296463599-rs8073jb4tpz51knz3wuum8c11mkotg8ytctdb8ink.jpg',
						'image_alt' => 'Urdu Bible distribution',
						'caption'   => 'Urdu Bible distribution',
					),
				)
			),
		),
	),
	'involved' => array(
		'label'  => __( 'Get involved', 'kingdom-revival' ),
		'fields' => array(
			'eyebrow' => krm_f( 'text', __( 'Small heading', 'kingdom-revival' ), 'Get Involved' ),
			'heading' => krm_f( 'html', __( 'Heading', 'kingdom-revival' ), 'Three Ways to Stand With Us' ),
			'items'   => krm_list_f(
				__( 'Ways', 'kingdom-revival' ),
				__( 'Way', 'kingdom-revival' ),
				array(
					'title' => krm_f( 'text', __( 'Title', 'kingdom-revival' ) ),
					'text'  => krm_f( 'textarea', __( 'Text', 'kingdom-revival' ) ),
				),
				array(
					array(
						'title' => 'Pray',
						'text'  => 'Intercede for the ministry, the families we serve, and the power of the Gospel.',
					),
					array(
						'title' => 'Give',
						'text'  => 'Provide Bibles, education, orphan care and emergency aid for families in crisis.',
					),
					array(
						'title' => 'Go',
						'text'  => 'Support outreach, church planting and humanitarian work on the ground.',
					),
				),
				__( 'The second card is the dark one. Icons follow the order: cross, heart, globe.', 'kingdom-revival' )
			),
		),
	),
	'founder'  => array(
		'label'  => __( 'Founder', 'kingdom-revival' ),
		'fields' => array(
			'image'        => krm_f( 'image', __( 'Photo', 'kingdom-revival' ), $krm_up . '2026/08/file_00000000b46471f484befac1dc0ee291.png' ),
			'image_alt'    => krm_f( 'text', __( 'Photo description (alt text)', 'kingdom-revival' ), 'Pastor Adil Arif, founder of Kingdom Revival Ministries' ),
			'eyebrow'      => krm_f( 'text', __( 'Small heading', 'kingdom-revival' ), 'Founder & Pastor' ),
			'heading'      => krm_f( 'html', __( 'Name', 'kingdom-revival' ), 'Pastor Adil Arif' ),
			'text'         => krm_f( 'textarea', __( 'Text', 'kingdom-revival' ), 'Pastor Adil leads Kingdom Revival Ministries in evangelism, discipleship and church ministry, with a heart for children and youth — and for practical care among villages, marginalised communities and brick kiln families.' ),
			'button_label' => krm_f( 'text', __( 'Button text', 'kingdom-revival' ), 'Contact Pastor Adil' ),
			'button_url'   => krm_f( 'url', __( 'Button link', 'kingdom-revival' ), '{email}' ),
		),
	),
	'cta'      => array(
		'label'  => __( 'Closing verse', 'kingdom-revival' ),
		'fields' => array(
			'quote'        => krm_f( 'textarea', __( 'Verse', 'kingdom-revival' ), '“Go therefore and make disciples of all nations.”' ),
			'cite'         => krm_f( 'text', __( 'Reference', 'kingdom-revival' ), 'Matthew 28:19' ),
			'button_label' => krm_f( 'text', __( 'Button text', 'kingdom-revival' ), 'Become a Partner' ),
			'button_url'   => krm_f( 'url', __( 'Button link', 'kingdom-revival' ), '{partner}' ),
		),
	),
	'float'    => array(
		'label'  => __( 'Floating “Donate” panel', 'kingdom-revival' ),
		'help'   => __( 'Uses the amounts set under “Hero and donation card”.', 'kingdom-revival' ),
		'fields' => array(
			'eyebrow' => krm_f( 'text', __( 'Small heading', 'kingdom-revival' ), 'SUPPORT THE MISSION' ),
			'heading' => krm_f( 'text', __( 'Heading', 'kingdom-revival' ), 'Choose an amount' ),
			'text'    => krm_f( 'textarea', __( 'Text', 'kingdom-revival' ), 'Your gift helps share the Gospel and care for vulnerable families.' ),
			'button'  => krm_f( 'text', __( 'Button text', 'kingdom-revival' ), 'Donate' ),
		),
	),
);
