<?php
/**
 * Ministry page 1: inner hero — the first photo (else Site text → Ministry pages → hero image), breadcrumb
 * (Home / What We Do / name), the group as the eyebrow, the title and the Excerpt. A "coming soon" ministry (Phase 22)
 * shows "Details about this ministry are coming soon." with Donate / Give (this ministry chosen) and Contact us.
 *
 * @param array $args { ministry, photos }
 *
 * @package Kingdom_Revival
 */

defined( 'ABSPATH' ) || exit;

$krm_m    = $args['ministry'];
$krm_hero = $args['photos'] ? $args['photos'][0][0] : krm_c( 'ministry.hero_image', 'site' );
krm_hero_preload( $krm_hero );
?>
<section class="page-hero" id="ministry-hero" style="background-image: url('<?php echo esc_url( krm_ref_url( $krm_hero ) ); ?>')<?php krm_bg_small( $krm_hero ); ?>">
<div class="wrap">
	<?php krm_breadcrumb_html( 'crumb-title' ); ?>
	<p class="eyebrow"><?php echo '' !== $krm_m['group'] ? esc_html( $krm_m['group'] ) : krm_text( krm_c( 'ministry.eyebrow', 'site' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- krm_text() escapes. ?></p>
	<h1 id="ministry-title"><?php echo esc_html( $krm_m['title'] ); ?></h1>
	<?php if ( ! empty( $krm_m['soon'] ) ) : ?>
	<p class="lead" id="ministry-description"><?php esc_html_e( 'Details about this ministry are coming soon.', 'kingdom-revival' ); ?></p>
	<div class="hero-actions">
	<a class="button button-primary" href="<?php echo esc_url( krm_ministry_donate_url( $krm_m['slug'] ) ); ?>"><?php echo krm_icon( 'heart18' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php esc_html_e( 'Donate / Give', 'kingdom-revival' ); ?></a>
	<a class="button button-light" href="<?php echo esc_url( krm_page_url( 'contact' ) ); ?>"><?php esc_html_e( 'Contact us', 'kingdom-revival' ); ?></a>
	</div>
	<?php else : ?>
	<p class="lead" id="ministry-description"><?php echo esc_html( $krm_m['desc'] ); ?></p>
	<div class="hero-actions">
	<a class="button button-primary" href="#support"><?php echo krm_icon( 'heart18' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php krm_t( 'ministry.donate_button', 'site' ); ?></a>
	</div>
	<?php endif; ?>
</div>
</section>
